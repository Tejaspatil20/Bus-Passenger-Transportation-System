
public class Gson {

	public String toJson(List<String> districts) {
		// TODO Auto-generated method stub
		return null;
	}

}
