package db;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RouteCountServlet")
public class RouteCountServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());

        PrintWriter pw = response.getWriter();
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "B49", "B49");
            String route = request.getParameter("Routes");

            // Use a prepared statement to avoid SQL injection
            String query = "SELECT COUNT(*) as student_count FROM student WHERE Routes = ?";
            try (PreparedStatement preparedStatement = con.prepareStatement(query)) {
                preparedStatement.setString(1, route);

                ResultSet rs = preparedStatement.executeQuery();
                int count = 0;

                while (rs.next()) {
                    count = rs.getInt("student_count");
                }

                pw.println("<h2>Count of Students for Route '" + route + "': " + count + "</h2>");
            } catch (Exception e) {
                pw.println("Error: " + e.getMessage());
            }

            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
