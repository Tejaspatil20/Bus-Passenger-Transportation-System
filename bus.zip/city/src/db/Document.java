package db;

public class Document {

	public void open() {
		// TODO Auto-generated method stub
		
	}

}
