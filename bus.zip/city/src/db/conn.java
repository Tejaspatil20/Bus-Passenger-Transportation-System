package db;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class conn
 */
@WebServlet("/conn")
public class conn extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public conn() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		PrintWriter pw=response.getWriter();
		try{ 
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","B49","B49");
			 Statement st=con.createStatement();
			 
			String fname=request.getParameter("fname");
			String lname=request.getParameter("lname");

			String department=request.getParameter("depart");

			String price=request.getParameter("price");

			 
			 String sqlQuery="insert into student values('"+fname+"','"+lname+"','"+department+"','"+price+"')";
			
			 
			 int rs=st.executeUpdate(sqlQuery);
			 pw.println(sqlQuery);
			 
			 int flag=0;
			 
			 if(rs==1)
				{
					pw.println("U have successfully inserted data");
				}
				else
				{
					pw.println("Ur data is not inserted");
				}
			
				st.close();
				con.close();
		
}
		
		catch(Exception e){ System.out.println(e);}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}