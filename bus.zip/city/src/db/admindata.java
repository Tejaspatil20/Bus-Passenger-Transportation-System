package db;
import java.io.*;
import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class admindata
 */
@WebServlet("/admindata")
public class admindata extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public admindata() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		PrintWriter pw=response.getWriter();
		try{ 
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","B49","B49");
			 Statement st=con.createStatement();
			 
			String PRN=request.getParameter("prn");
			String Month=request.getParameter("month");
			

					
			 
			
			int rs=st.executeUpdate("insert into admin values('"+PRN+"','"+Month+"')");
			 pw.println(rs);
			// int flag=0;

             
				if(rs==1)
				{
					pw.println("U have successfully inserted data");
				}
				else
				{
					pw.println("Ur data is not inserted");
				}
			 
		/*	 while(rs.next())
			 {
				 flag=1;
				 pw.println("<br>  "+rs.getString(1)+" "+rs.getString(2));
			 }
			 
			 if(flag==0)
			 {
				 pw.println("Data not found for roll number");
			 }*/
			
			
				st.close();
				con.close();
		
}
		
		catch(Exception e){ System.out.println(e);}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
