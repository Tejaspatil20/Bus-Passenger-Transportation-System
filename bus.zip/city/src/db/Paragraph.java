package db;

public class Paragraph {

}
