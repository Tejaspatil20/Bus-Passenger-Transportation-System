
package db;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/display")
public class display extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public display() {
        // TODO Auto-generated constructor stub
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "B49", "B49");
            Statement st = con.createStatement();

            String PRN = request.getParameter("prn");

           ResultSet rs = st.executeQuery("select * from student  JOIN admin ON student.PRN=admin.PRN where student.PRN=" + PRN + "");
          
            int flag=0;
         

            while (rs.next()) {
                flag = 1;
                // Set the result as a request attribute
                request.setAttribute("result", rs.getString(1) + " " + rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getString(6)+" "+rs.getString(7)+" "+rs.getString(8));
            }
            ResultSet monthResultSet = st.executeQuery("SELECT month FROM admin WHERE PRN=" + PRN);

            while (monthResultSet.next()) {
                // Set the result as a request attribute
                request.setAttribute("result1", monthResultSet.getString("month"));
            }
           

            if (flag == 0) {
                // Set the result as a request attribute
                request.setAttribute("result", "Data not found for roll number");
            }
           
            st.close();
            con.close();

            // Forward the result to the displayResult.jsp page
            request.getRequestDispatcher("/displayResult.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}